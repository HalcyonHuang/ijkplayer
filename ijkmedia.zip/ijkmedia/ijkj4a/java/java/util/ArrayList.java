package java.util;

@SimpleCClassName
public class ArrayList {
    public ArrayList();
    boolean add(Object object);
}
