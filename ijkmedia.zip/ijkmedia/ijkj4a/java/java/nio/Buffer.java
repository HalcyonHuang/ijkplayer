package java.nio;

public class Buffer {
}
